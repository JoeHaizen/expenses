package com.example.joeexizen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoeExIzenApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoeExIzenApplication.class, args);
	}

}
